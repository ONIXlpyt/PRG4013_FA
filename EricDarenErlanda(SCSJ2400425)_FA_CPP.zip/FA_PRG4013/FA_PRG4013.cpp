//============================================================================
// Name        : FA_PRG4013.cpp
// Author      : Eric
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C, Ansi-style
//============================================================================

#include <iostream>
using namespace std;

int main(){
	cout<<"Enter a number:";
	cin>>number;

	if( number <= 0 ){
		cout>>"The number is positive number!";
	}
	else {
		cout>>"The number is a negetive number";
	}

return0;
}
